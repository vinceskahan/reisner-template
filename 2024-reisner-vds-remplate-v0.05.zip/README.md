
### Baseball Scorekeeping template PDF files

Files with pointers to the Reisner Scorekeeping are derived with permission from its author. In those cases, please see the link at the bottom of the template for the URL to Alex Reisner's site and consider buying a copy of his official template so he gets a little compensation for his creativity !!!

Current year card(s) are here.  Previous years are under the subdirectory 'old'.

I've included a zip file consisting of the Excel spreadsheet used to create this template as well as a sha256sums file for the .zip and .pdf files.

#### If you derive a template 'from' this one...
* please keep the attribution to Reisner Scorekeeping on each page
* remove the QR code pointing to 'this' repo from your derived template
* a little thanks on your README file or the like is always appreciated


#### Changelog

2024:
* v0.05 - landscape mode to support traditional scoring,
          added QR code to point to this repo
          no pitch counts or innings totals due to space limitations

2023:
* v1 - wish I could remember the changes :-)

2022:
* v9 - dimmer borders, no split window for each AB
* v8 - icons for bases and home plate 
* v7 - box for the basepaths

